package org.dojo_java_17;

public class PlatformThread extends Thread {
    public void run() {
        // Le code à exécuter dans le thread
        for (int i = 0; i < 5; i++) {
            System.out.println("Iteration " + i + " dans le thread " + Thread.currentThread().getId());
        }
    }

    public static void main(String[] args) {
        // Crée une instance du thread
        PlatformThread monThread = new PlatformThread();

        // Démarre le thread
        monThread.start();

        // Le code ci-dessous sera exécuté dans le thread principal
        for (int i = 0; i < 5; i++) {
            System.out.println("Iteration " + i + " dans le thread principal");
        }
    }
}
