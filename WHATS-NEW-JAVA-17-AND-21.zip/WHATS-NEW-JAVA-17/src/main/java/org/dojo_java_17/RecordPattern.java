package org.dojo_java_17;

public class RecordPattern {
    record Point(int x, int y) {}

    static void printSum(Object obj) {
        if (obj instanceof Point p) {
            int x = p.x();
            int y = p.y();
            System.out.println(x+y);
        }
    }
}
