package org.dojo_java_17;

import java.util.ArrayList;
import java.util.List;

public class SequencedCollections {
    public static void main(String[] args) {
    }
}
