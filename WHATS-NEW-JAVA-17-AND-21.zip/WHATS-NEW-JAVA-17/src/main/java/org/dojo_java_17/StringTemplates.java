package org.dojo_java_17;

import java.util.Arrays;;
import java.util.Collections;
import java.util.random.RandomGenerator;


public class StringTemplates {

    // Preview
    public static void main(String[] args) {
        var liste = Arrays.asList(1, 2, 3);
        var randomizer = RandomGenerator.getDefault();

        Collections.shuffle(liste);

        liste.forEach(System.out::println);
    }

}
