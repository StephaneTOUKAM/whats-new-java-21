package org.dojo_java_21;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello and welcome!");
    }
}