package org.dojo_java_21.amber.preview;

public class InstanceMainMethods {
    void main(){
        System.out.println("On peut desormais declarer une methode main avec ou sans tableau de chaînes de caractères en paramètre");
    }
}
