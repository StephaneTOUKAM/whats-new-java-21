void main(){
    System.out.println("On peut desormais declarer une classe sans nom");
}
